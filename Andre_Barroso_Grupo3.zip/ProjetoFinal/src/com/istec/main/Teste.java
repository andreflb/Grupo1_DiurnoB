package com.istec.main;

import com.istec.pagina.LoginPage;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginPage login = new LoginPage();
		login.setVisible(true);
	}

}
